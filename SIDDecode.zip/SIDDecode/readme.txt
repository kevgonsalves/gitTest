SIDDecode 1.0
Released 07/19/2007
Written by Mitch Bartlett at Technipages.com - please support the site with a link or something!


To run GetSID, you must have the .Net Framework installed on your computer. You can download it at http://www.microsoft.com/downloads/details.aspx?FamilyId=10CC340B-F857-4A14-83F5-25634C3BF043&displaylang=en


SIDDecode will take a given SID or security identifier and convert it to a username and domain.


Simply enter the SID andit will provide you with the username and domain for that SID.


If you have questions or comments, please send them to mitch.bartlett@gmail.com